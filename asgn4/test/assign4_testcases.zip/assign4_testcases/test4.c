a = foo();

int foo(){
    return bar;
}