if (c) {
	if (d)
    	d++
    else
        d--
}