if (c && d)
    d++
else if (d & e) // bitwise and
    e++
else
    d--