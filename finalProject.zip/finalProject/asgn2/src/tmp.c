#include <stdio.h>
int arr1[] = {1,2,3} ;
int main(int argc, char const *argv[])
{
	int arr[32];
	printf("%dint arr1[] = {1,2,3} ;",arr1[1]);
    return 0;
}
